<?php
session_start();
include "lib/config.php";
switch ($_GET["act"]) {
 case 'kota':
      autocomplete('kabupaten','id_kab','nama_kab','id_prov',$_POST['id']);
    
break;

    case 'kecamatan':
       autocomplete('kecamatan','id_kec','nama_kec','id_kab',$_POST['id']); 
    break;

    case 'provinsi':
      autocomplete('provinsi','id_prov','nama_prov'); 
    break;
  
  default:
    
    break;
}

function selectchain($tabel=null,$kolom_id=null,$kolom_nama=null,$idwhere,$idvalue)
{
    global $db;
    $response = [];
    $sql = "SELECT $kolom_id, $kolom_nama FROM $tabel WHERE $where = '".$id."' GROUP BY $kolom_nama";
    //echo $sql;
    foreach ($db->custom_query($sql) as $row) {
      $response[] = array("id"=>$row->$kolom_id, "text"=>$row->$kolom_nama);
    }
     echo json_encode($response);
}

?>