<?php 
//include config database
include "lib/config.php";?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>PHP Ajax Chaining Datatable server side </title>

    <style type="text/css">
    /* centered columns styles */
    .row-centered {
        text-align: center;
    }

    .col-centered {
        display: inline-block;
        float: none;
        /* reset the text-align */
        text-align: left;
        /* inline-block space fix */
        margin-right: -4px;
    }

    #loader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1000;
        background-color: #fff;
        opacity: .8;
    }

    .ajax-loader {
        position: fixed;
        left: 50%;
        top: 50%;
        margin-left: -32px;
        /* -1 * image width / 2 */
        margin-top: -32px;
        /* -1 * image height / 2 */
        display: block;
    }

    .glyphicon-refresh-animate {
        -animation: spin .7s infinite linear;
        -webkit-animation: spin2 .7s infinite linear;
    }

    @-webkit-keyframes spin2 {
        from {
            -webkit-transform: rotate(0deg);
        }

        to {
            -webkit-transform: rotate(360deg);
        }
    }

    @keyframes spin {
        from {
            transform: scale(1) rotate(0deg);
        }

        to {
            transform: scale(1) rotate(360deg);
        }
    }
    </style>
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Datatable css -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">




    <!-- library chosen untuk merubah select biasa jadi searchable -->
    <link href="assets/css/chosen.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">




</head>

<body>
    <div id="loader" style="display:none">
        <img src="assets/images/loadnya.gif" class="ajax-loader" />
    </div>


    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row row-centered">
            <h1><a href="http://wildantea.com/chaining-datatable-server-side-processing/" target="_blank">PHP Ajax
                    Chaining Datatable server side</a></h1>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-danger">
                    <div class="box-header with-border">
                        <h3 class="box-title">Filter</h3>
                    </div>
                    <div class="box-body">
                        <form class="form-horizontal">
                            <div class="form-group">
                                <label for="Provinsi" class="control-label col-lg-2">Provinsi</label>
                                <div class="col-lg-4">
                                    <select name="provinsi" id="provinsi" class="form-control chzn-select" tabindex="2">
                                        <option value="all">Semua</option>
                                        <?php 
						               //ambil data provinsi dari table provinsi
						               // $data = $db->fetch_all("provinsi");
						               // //lakukan looping data
						               // foreach ($data as $isi) {
						               //    echo "<option value='$isi->id_prov'>$isi->nama_prov</option>";
						               // } 
						               ?>
                                    </select>

                                </div>
                            </div><!-- /.form-group -->


                            <div class="form-group">
                                <label for="kabupaten" class="control-label col-lg-2">Kabupaten</label>
                                <div class="col-lg-4">
                                    <select id="kabupaten" class="form-control chzn-select" tabindex="2">
                                        <option value="all">Semua</option>
                                    </select>

                                </div>
                                <img id="img_loader" style="display:none" src="assets/images/ajax-loader.gif">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label for="kecamatan" class="control-label col-lg-2">Kecamatan</label>
                                <div class="col-lg-4">
                                    <select class="form-control" id="kecamatan">
                                        <option value="all">Semua</option>
                                    </select>
                                </div>
                                <img id="img_loader_2" style="display:none" src="assets/images/ajax-loader.gif">
                            </div><!-- /.form-group -->

                            <div class="form-group">
                                <label for="tags" class="control-label col-lg-2">&nbsp;</label>
                                <div class="col-lg-10">
                                    <span id="kirim_filter" class="btn btn-primary btn-flat">Submit</span>
                                </div>
                            </div><!-- /.form-group -->
                        </form>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>
        <!-- Heading Row -->
        <div class="row row-centered">
            <div class="col-md-12">


                <table id="contoh" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>Provinsi</th>
                            <th>Kabupaten</th>
                            <th>Kecamatan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>

            </div>
        </div>
    </div>

    <p><a href="http://wildantea.com">Main BLog</a></p>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="assets/js/jquery-1.12.0.min.js"></script>
    <!-- datatables js -->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.min.js"></script>


    <!-- library select2 untuk merubah select biasa jadi searchable -->
    <script src="assets/js/chosen.jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<!-- '<?=base_admin();?>modul/pelanggan/pelanggan_action.php?act=provinsi' -->
    <!-- let's begin the script -->
    <script type="text/javascript">
    $(document).ready(function() {
    		autocomplete("#provinsi",'url.php.php?act=provinsi');
        	$("#provinsi,#kabupaten,#kecamatan").select2();
            ajaxChained('#provinsi', '#kabupaten', 'kota');
            ajaxChained('#kabupaten', '#kecamatan', 'kecamatan');
        

        
            //ajaxChained('#kecamatan', '#kelurahan', 'kelurahan');
       




        //simpan datatable ke variable dataTable, 
        var dataTable = $("#contoh").dataTable({
            'bProcessing': true,
            'bServerSide': true,
            "deferRender": true,

            //disable order dan searching pada kolom pertama dan terakhir 
            "columnDefs": [{
                "targets": [0, 4],
                "orderable": false,
                "searchable": false

            }],
            "ajax": {
                url: "data_chain.php",
                type: "post",
                error: function(xhr, error, thrown) {
                    console.log(xhr);

                }
            },

        });


        //jika klik filter di submit
        $('#kirim_filter').on('click', function() {
            //destory datatable
            dataTable.fnDestroy();
            //inisialiasi kembali datatable dengan data baru dari server
            $("#contoh").dataTable({
                'bProcessing': true,
                'bServerSide': true,
                "deferRender": true,

                //disable order dan searching pada kolom pertama dan terakhir 
                "columnDefs": [{
                    "targets": [0, 4],
                    "orderable": false,
                    "searchable": false

                }],
                "ajax": {
                    url: "data_chain.php",
                    type: "post", // method  , by default get
                    //bisa kirim data ke server
                    data: function(d) {
                        //ambil value select provinsi terpilih dan kirim ke data.php
                        d.provinsi = $("#provinsi").val();
                        //ambil value select kabupaten terpilih dan kirim ke data.php
                        d.kabupaten = $("#kabupaten").val();
                        //ambil value select kecamatan terpilih dan kirim ke data.php
                        d.kecamatan = $("#kecamatan").val();
                    },
                    error: function(xhr, error, thrown) {
                        console.log(xhr);

                    }
                },
                "language": {
                    "processing": "<span class=\"glyphicon glyphicon-refresh glyphicon-refresh-animate\"></span> Loading data, Please wait..."
                },

            });


        });
    });

    function ajaxChained(source,target,slug){
		  $(source).on('change',function(){
		  var pid = $(source+' option:selected').val(); //$(this).val();

		  $.ajax({
		        type: 'POST',
		        url: 'url.php?act='+slug,
		        dataType: 'html',
		        data: { id : pid },
		        success: function(txt){
		            //no action on success, its done in the next part
		        }
		    }).done(function(data){
		        //get JSON
		        data = $.parseJSON(data);

		        //generate <options from JSON
		        var list_html = '';
		        $.each(data, function(i, item) {
		            list_html += '<option value='+data[i].id+'>'+data[i].text+'</option>';
		        });
		        //replace <select2 with new options
		        $(target).html(list_html);
		        //change placeholder text
		        $(target).select2({placeholder: data.length +' results'});
		    });
		  })
		}

		function autocomplete(source,slug){

		  $(source).select2({
		    placeholder: 'Pilih Salah Satu',
		    language: {
		        noResults: function() {
		            return `<button style="width: 100%" type="button"
		                  class="btn btn-primary" 
		                  onClick='tambah()'>+ Tambah</button>
		                  </li>`;
		        }
		    },
		    ajax: {
		        url: slug,
		        dataType: 'json',
		        delay: 250,
		        processResults: function(data) {
		            return {
		                results: data
		            };
		        },
		        cache: true
		    },
		    escapeMarkup: function(markup) {
		        return markup;
		    }
		});

	}
    </script>

</body>

</html>