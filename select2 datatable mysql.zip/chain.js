function ajaxChained(source,target,slug){
  $(source).on('change',function(){
  var pid = $(source+' option:selected').val(); //$(this).val();
  var url ;
  $.ajax({
        type: 'POST',
        url: '{{ site_url() }}act='+slug+'/'+pid,
        dataType: 'html',
        data: { id : pid },
        success: function(txt){
            //no action on success, its done in the next part
        }
    }).done(function(data){
        //get JSON
        data = $.parseJSON(data);

        //generate <options from JSON
        var list_html = '';
        $.each(data, function(i, item) {
            list_html += '<option value='+data[i].id+'>'+data[i].name+'</option>';
        });
        //replace <select2 with new options
        $(target).html(list_html);
        //change placeholder text
        $(target).select2({placeholder: data.length +' results'});
    });
  })
}
//cara penggunaan
ajaxChained('#provinsi','#kota','regency');
ajaxChained('#wilkab','#wilkec','district');
ajaxChained('#wilkec','#wildes','village');